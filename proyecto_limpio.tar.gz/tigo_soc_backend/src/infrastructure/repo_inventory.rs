// * * * REPOSITORIO DE INVENTARIO Y GESTIÓN DE NODOS DE RED * * *
#![allow(dead_code)]
use sqlx::{Error, PgPool, Row};
use crate::domain::models::NetworkNode;

#[derive(Clone)]
pub struct InventoryRepository {
    pub pool: PgPool,
}

impl InventoryRepository {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }

    // * * * CREACIÓN O ACTUALIZACIÓN ATÓMICA DE NODO * * *
    pub async fn create_node(
        &self,
        hostname: &str,
        ip_address: &str,
        type_id: Option<i32>,
        protocol_id: Option<i32>,
    ) -> Result<i32, Error> {
        self.create_node_with_vendor(hostname, ip_address, type_id, protocol_id, None, None).await
    }

    pub async fn create_node_with_vendor(
        &self,
        hostname: &str,
        ip_address: &str,
        type_id: Option<i32>,
        protocol_id: Option<i32>,
        mac_address: Option<&str>,
        vendor: Option<&str>,
    ) -> Result<i32, Error> {
        let row = sqlx::query(
            "INSERT INTO network_nodes (hostname, ip_address, type_id, protocol_id, mac_address, vendor)
             VALUES ($1, $2, $3, $4, $5, $6)
             ON CONFLICT (hostname) DO UPDATE SET
                 ip_address = EXCLUDED.ip_address,
                 type_id = EXCLUDED.type_id,
                 protocol_id = EXCLUDED.protocol_id,
                 mac_address = COALESCE(EXCLUDED.mac_address, network_nodes.mac_address),
                 vendor = COALESCE(EXCLUDED.vendor, network_nodes.vendor)
             RETURNING node_id"
        )
        .bind(hostname)
        .bind(ip_address)
        .bind(type_id)
        .bind(protocol_id)
        .bind(mac_address)
        .bind(vendor)
        .fetch_one(&self.pool)
        .await?;

        Ok(row.get("node_id"))
    }

    // * * * OBTENER LISTADO COMPLETO DE NODOS * * *
    pub async fn get_nodes(&self) -> Result<Vec<NetworkNode>, Error> {
        sqlx::query_as::<_, NetworkNode>(
            "SELECT node_id, hostname, ip_address, type_id, protocol_id, mac_address, vendor FROM network_nodes ORDER BY node_id ASC"
        )
        .fetch_all(&self.pool)
        .await
    }

    // * * * BUSCAR NODO POR DIRECCIÓN IP * * *
    pub async fn get_node_by_ip(&self, ip_address: &str) -> Result<Option<NetworkNode>, Error> {
        sqlx::query_as::<_, NetworkNode>(
            "SELECT node_id, hostname, ip_address, type_id, protocol_id, mac_address, vendor FROM network_nodes WHERE ip_address = $1"
        )
        .bind(ip_address)
        .fetch_optional(&self.pool)
        .await
    }

    // * * * BUSCAR NODO POR IDENTIFICADOR ÚNICO * * *
    pub async fn get_node_by_id(&self, node_id: i32) -> Result<Option<NetworkNode>, Error> {
        sqlx::query_as::<_, NetworkNode>(
            "SELECT node_id, hostname, ip_address, type_id, protocol_id, mac_address, vendor FROM network_nodes WHERE node_id = $1"
        )
        .bind(node_id)
        .fetch_optional(&self.pool)
        .await
    }
}
